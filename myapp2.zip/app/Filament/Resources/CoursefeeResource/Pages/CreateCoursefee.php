<?php

namespace App\Filament\Resources\CoursefeeResource\Pages;

use App\Filament\Resources\CoursefeeResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateCoursefee extends CreateRecord
{
    protected static string $resource = CoursefeeResource::class;
}
