<?php

namespace App\Filament\Resources\PersonalInfoResource\Pages;

use App\Filament\Resources\PersonalInfoResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePersonalInfo extends CreateRecord
{
    protected static string $resource = PersonalInfoResource::class;


}
