<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\FilamentBrandServiceProvider::class,
    App\Providers\Filament\AdminPanelProvider::class,
];
